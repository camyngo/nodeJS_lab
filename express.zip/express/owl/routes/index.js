var express = require('express');
var router = express.Router();
var request = require('request');

/* GET home page. */
router.get('/', function(req, res, next) {
  res.render('index', { title: 'Express' });
});
/* new route adding*/
router.get('/dictionary', function(reg, res, next) {
  var url = "https://owlbot.info/api/v2/dictionary/"
  url += reg.query['q'];
  url += "?format=json";
  console.log(url);
  request(url).pipe(res);
})

/* adding on getting cities name*/
router.get("/cities", function(req, res, next) {
  var fs = require('fs');
  fs.readFile(__dirname + "/cities.dat.txt", function(err, data) {
    if (err) throw err;

    /* putting in the regular express link*/
    var myRe = new RegExp("^" + req.query.q);

    /*storing cities into a JSON array*/
    var jsonResult = [];
    var cities = data.toString().split("\n");
    for (var i = 0; i < cities.length; i++) {

      var result = cities[i].search(myRe);

      if (result != -1) {

        jsonResult.push({ city: cities[i] });
      }
    }
    res.status(200).json(jsonResult);
  });
});

module.exports = router;
